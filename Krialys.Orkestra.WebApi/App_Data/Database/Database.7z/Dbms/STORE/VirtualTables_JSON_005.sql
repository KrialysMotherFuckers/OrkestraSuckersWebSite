DROP TABLE IF EXISTS DOCUTABLE;
DROP VIEW IF EXISTS VT_DOCUTABLE;

CREATE TABLE IF NOT EXISTS DOCUTABLE -- https://www.sqlitetutorial.net/sqlite-generated-columns/
(
  RowId INTEGER PRIMARY KEY NOT NULL,
  RefId INTEGER GENERATED ALWAYS AS (json_extract(Body, '$.RefId')) STORED NOT NULL,
  Body TEXT
);

-- Adding constraints to avoid discrepencies in database
CREATE INDEX IF NOT EXISTS xRefId ON DOCUTABLE(RefId);

/*
-- 1st item >> {"Day":60,"RefId":1,"Name":"Tomates","Status":"R�colte"}
INSERT INTO DOCUTABLE VALUES
	(null, json('{"RefId":1,"Name":"Tomates","Status":"Germe","Day":3}')),
	(null, json('{"RefId":1,"Day":51,"Status":"Fleuri"}')),
	(null, json('{"RefId":1,"Day":60,"Status":"R�colte"}'));
	
-- 2nd item >> {"RefId":2,"Name":"Arthur","Sex":"M"}
INSERT INTO DOCUTABLE VALUES
	(null, json('{"RefId":2,"Name":"Arthur"}')),
	(null, json('{"RefId":2,"Sex":"F"}')),
	(null, json('{"RefId":2,"Sex":"M"}'));

-- 3rd item >> {"Action":"Brossage des dents","Age":15,"RefId":3,"Name":"John"}
INSERT INTO DOCUTABLE VALUES
	(null, json('{"RefId":3,"Name":"John","Age":12,"Action":"D�jeune"}')),
	(null, json('{"RefId":3,"Age":15}')),
	(null, json('{"RefId":3,"Action":"Brossage des dents"}'));
*/


INSERT INTO DOCUTABLE VALUES
	(null, json('{"RefId":1,"Name":"Tomates","Status":"Germe","Day":1}')),
	(null, json('{"RefId":2,"Name":"Persil","Status":"Germe","Day":1}')),
	(null, json('{"RefId":3,"Name":"Ail","Status":"Germe","Day":1}'));

-- Aggregate
CREATE VIEW IF NOT EXISTS VT_DOCUTABLE AS
SELECT Body.RowId, Body.RefId, json_group_object(Body.key, Body.value) AS Body
FROM
(
	SELECT el.RowId, el.RefId, el.key, el.value
		FROM
		(
		    SELECT dt.RowId, dt.RefId, cj.key, cj.value, cj.type
			FROM DOCUTABLE dt    
		    INNER JOIN json_each(dt.Body) AS cj
		) AS el
		INNER JOIN
		(		
			SELECT MAX(dt.RowId) AS RowId, dt.RefId, cj.key
			FROM DOCUTABLE dt    
			INNER  JOIN json_each(dt.Body) AS cj
		    GROUP BY dt.RefId, cj.key	
		) AS elMAX
		ON elMax.RowId = el.RowId AND elMax.RefId = el.RefId AND elMax.key = el.key
) AS Body
GROUP BY Body.RefId;

select * from VT_DOCUTABLE vt;