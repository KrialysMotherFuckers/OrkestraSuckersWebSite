DROP TABLE IF EXISTS TT_TRACKINGS;
DROP VIEW IF EXISTS VT_TRACKINGS;

CREATE TABLE IF NOT EXISTS TT_TRACKINGS -- https://www.sqlitetutorial.net/sqlite-generated-columns/
(
  RowId INTEGER PRIMARY KEY NOT NULL,
  LogId TEXT GENERATED ALWAYS AS (json_extract(Body, '$.LogId')) STORED NOT NULL,
  Body TEXT
);

-- Adding constraints to avoid discrepencies in database
CREATE INDEX IF NOT EXISTS xLogId ON TT_TRACKINGS(LogId);

-- 1st item >> {"Day":60,"LogId":"42140d58-ea46-4f23-a1d5-8fe96562b84e","Name":"Tomates","Status":"Récolte"}
INSERT INTO TT_TRACKINGS VALUES
	(null, json('{"LogId":"42140d58-ea46-4f23-a1d5-8fe96562b84e","Name":"Tomates","Status":"Germe","Day":3}')),
	(null, json('{"LogId":"42140d58-ea46-4f23-a1d5-8fe96562b84e","Day":51,"Status":"Fleuri"}')),
	(null, json('{"LogId":"42140d58-ea46-4f23-a1d5-8fe96562b84e","Day":60,"Status":"Récolte"}'));
	
-- 2nd item >> {"LogId":"b0898c88-954f-4336-a5a3-f2b32b00fb52","Name":"Arthur","Sex":"M"}
INSERT INTO TT_TRACKINGS VALUES
	(null, json('{"LogId":"b0898c88-954f-4336-a5a3-f2b32b00fb52","Name":"Arthur"}')),
	(null, json('{"LogId":"b0898c88-954f-4336-a5a3-f2b32b00fb52","Sex":"F"}')),
	(null, json('{"LogId":"b0898c88-954f-4336-a5a3-f2b32b00fb52","Sex":"M"}'));

-- 3rd item >> {"Action":"Brossage des dents","Age":15,"LogId":"ec55b2dc-6e19-4b94-9301-f6277935bff8","Name":"John"}
INSERT INTO TT_TRACKINGS VALUES
	(null, json('{"LogId":"ec55b2dc-6e19-4b94-9301-f6277935bff8","Name":"John","Age":12,"Action":"Déjeune"}')),
	(null, json('{"LogId":"ec55b2dc-6e19-4b94-9301-f6277935bff8","Age":15}')),
	(null, json('{"LogId":"ec55b2dc-6e19-4b94-9301-f6277935bff8","Action":"Brossage des dents"}'));
	
-- Aggregate
CREATE VIEW IF NOT EXISTS VT_TRACKINGS AS
SELECT Body.RowId, Body.LogId, json_group_object(Body.key, Body.value) AS Body
FROM
(
	SELECT el.RowId, el.LogId, el.key, el.value
		FROM
		(
		    SELECT dt.RowId, dt.LogId, cj.key, cj.value, cj.type
			FROM TT_TRACKINGS dt    
		    INNER JOIN json_each(dt.Body) AS cj
		) AS el
		INNER JOIN
		(		
			SELECT MAX(dt.RowId) AS RowId, dt.LogId, cj.key
			FROM TT_TRACKINGS dt    
			INNER  JOIN json_each(dt.Body) AS cj
		    GROUP BY dt.LogId, cj.key	
		) AS elMAX
		ON elMax.RowId = el.RowId AND elMax.LogId = el.LogId AND elMax.key = el.key
) AS Body
GROUP BY Body.LogId;

select * from VT_TRACKINGS vt;